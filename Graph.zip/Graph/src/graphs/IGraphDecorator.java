package graphs;

public abstract class IGraphDecorator extends IGraph {
	IGraph comp;
}
