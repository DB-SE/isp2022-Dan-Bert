package edges;

public abstract class IEdgeDecorator extends IEdge {
	protected IEdge comp;
}
