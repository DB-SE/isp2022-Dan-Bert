package nodes;

public abstract class INodeDecorator<T> extends INode<T>{
	INode<T> comp;
}
