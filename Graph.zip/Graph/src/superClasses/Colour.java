package superClasses;

public enum Colour {
	RED,
	BLUE,
	GREEN,
	YELLOW,
	BLACK,
	WHITE
}
